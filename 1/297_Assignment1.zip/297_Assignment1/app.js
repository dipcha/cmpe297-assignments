
function increment_count(variable) {
    // retrieve
    var str_count = localStorage.getItem(variable);

    if(str_count == null) {
        var count = 0;
    } else {
        count = parseInt(str_count);
    }
    count++;
    // store
    localStorage.setItem(variable, count);
    console.log(variable + count);
}


function submit(page_num, question_type) {

    if(page_num > 1 && page_num < 6) {
        var id = $('input[name="question"]:checked').attr('id');
        var isCorrect = $("#" +id).attr('data-correct')

        if(question_type== "reading") {
            var id = $('input[name="question1"]:checked').attr('id');
            var isCorrect1 = $("#" +id).attr('data-correct')
            if(isCorrect1 != "true") {
                isCorrect = false;
            }
        }
        if(isCorrect == 'true') {
            console.log("Correct Answer!!!");
            increment_count(question_type)
        } else {
            console.log("False Answer!!!" + "id");
        }
    }

    window.location.href = "Page" + page_num + ".html"
}

function getScore() {
    // retrieve
    var quantitative_score =  localStorage.getItem("quantitative");
    var reading_score = localStorage.getItem("reading");
    var audioVisual_count = localStorage.getItem("audioVisual");

    $("#q_correct").html(quantitative_score);
    var score = calculate_score(quantitative_score,2);
    $("#q_numOfQuestions").html(2);
    $("#q_score").html(score);

    $("#r_correct").html(reading_score);
    var score = calculate_score(reading_score,1);
    $("#r_numOfQuestions").html(1);
    $("#r_score").html(score);

    $("#a_correct").html(audioVisual_count);
    var score = calculate_score(audioVisual_count,1);
    $("#a_numOfQuestions").html(1);
    $("#a_score").html(score);

    deleteVariables();
}

function calculate_score(score, numOfQuestions ) {
    if(score == null) {
        score = 0;
    } else {
        score = ( parseInt(score) / numOfQuestions) * 100;
    }
    console.log("score" +  score);
    return score;
}

function cancel() {
    console.log("Hello World!!!");
    $('input[name="equation"]:checked').removeAttr('checked');
}

function fillOption(myRadio) {
    var currentValue = myRadio.value;
    var name = myRadio.name;
    $("#" + name).html(currentValue);
}

function deleteVariables() {
    localStorage.removeItem("quantitative");
    localStorage.removeItem("reading");
    localStorage.removeItem("audioVisual");
}