var globalScore = 0; 

function quiz(selectedButton) { 
    var score1 = document.form1.q1.selectedIndex
    var score2 = document.form1.q2.selectedIndex
   
    if (score1 === "a1") { 
        
        globalScore++ ; 
    } 
    if(score2==="a2")
    {
      globalScore++ ;   
    }
    score.value = globalScore; 
    return score;
} 