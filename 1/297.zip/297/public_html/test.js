
function scoreclaculation() {
	
	var score = 0;
	var radios = document.getElementsByName('a1');
	for (var i = 0, length = radios.length; i < length; i++) {
	    if (radios[i].checked) {
	        
	      //  alert(radios[i].value);
			if(radios[i].value == 'true')
				{
				score = 1;
				}
	       // alert(score);
	        break;
	    }
	}
	sessionStorage.setItem("math1", score);
	//answer1(score);
    
}
